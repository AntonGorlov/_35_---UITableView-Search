//
//  AGSection.m
//  UITableView Search (Lesson 35)
//
//  Created by Anton Gorlov on 26.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGSection.h"

@implementation AGSection

@end
