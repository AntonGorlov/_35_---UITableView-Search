//
//  AGSection.h
//  UITableView Search (Lesson 35)
//
//  Created by Anton Gorlov on 26.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGSection : NSObject
// соз класс,чтобы он хранил название секций и массив айтемов
@property (strong, nonatomic) NSString* sectionName;
@property (strong, nonatomic) NSMutableArray* itemsArray;
@end
