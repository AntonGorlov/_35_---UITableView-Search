//
//  NSString+AGRandom.m
//  UITableView Search (Lesson 35)
//
//  Created by Anton Gorlov on 26.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "NSString+AGRandom.h"

@implementation NSString (AGRandom)

// "+" означает,что метод будет отправлен классу (вызван у класса)

//генерируем случайную строку min = 5, max = 15


+ (NSString *)randomAlphanumericString {

int lenght = arc4random() % 11 + 5;
    
    return [self randomAlphanumericStringWithLength:lenght];
}
+ (NSString *)randomAlphanumericStringWithLength:(NSInteger)length {

    NSString *letters = @"abcdefghijklmnopqrstuvwxyz";//ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //0123456789

    NSMutableString *randomString = [NSMutableString stringWithCapacity:length]; //Возвращает пустой объект NSMutableString с начальным хранения для заданного количества символов
    
    for (int i = 0; i < length; i++) {
        [randomString appendFormat:@"%C", [letters characterAtIndex:arc4random() % [letters length]]]; // appendFormat:@"%C" - формат строки
    }
    
    return randomString;
}




@end
