//
//  ViewController.m
//  UITableView Search (Lesson 35)
//
//  Created by Anton Gorlov on 26.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "NSString+AGRandom.h"
#import "AGSection.h"
@interface ViewController ()

@property (strong, nonatomic) NSArray* namesArray;
//соз массив из секций
@property (strong, nonatomic) NSArray* sectionsArray;

@property (strong, nonatomic) NSOperation* currentOperation; //текущая операция,делаем @property ,чтобы сохранять операцию
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSMutableArray* array = [NSMutableArray array];
    
    for (int i = 0; i < 10000; i++) { // 10000 случайных строк
        
        [array addObject:[[NSString randomAlphanumericString] capitalizedString]];
    }
    
    //сортируем массив
    
    NSSortDescriptor* sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"self" ascending:YES]; //NSSortDescriptor говорит как нам надо сортировать, ключ у нас "self" так как у нас все это строки
    

    [array sortUsingDescriptors:@[sortDescriptor]];
    
    self.namesArray = array;
    
      /*
       [array sortUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]]; // или  [array sortUsingDescriptors:@[sortDescriptor]];
       self.sectionsArray = [NSMutableArray array];

   // self.namesArray = [NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14", nil]; //создаем массив (инициализируем)
    //или другой способ создания массива - self.namesArray = @[@"1",@"2",@"3"];
    
    NSString* currentLetter = nil; //текущая буква
    
    for (NSString* string in self.namesArray) { //для каждой строки массива надо взять первую букву у этой строки
        
        NSString* firstLetter = [string substringToIndex:1]; //берем у этой строки первую букву
        
        AGSection* section = nil;
        
        if (![currentLetter isEqualToString:firstLetter]) { //если currentLetter не равна ,тогда соз новую секцию (это для первого слова)
            
            section = [[AGSection alloc]init]; // инициализируем
            
            section.sectionName = firstLetter; //имя секции
            
            section.itemsArray = [NSMutableArray array];
            
            currentLetter = firstLetter; //чтобы узнали какая первая буква,чтобы в след. раз не соз ее
            
            [self.sectionsArray addObject:section]; //добавляем в массив эту section
            
        }else { // а для 2-го слова
        
            section = [self.sectionsArray lastObject]; // секцию берем уже из массива (мы не будем соз еще раз секцию для той же самой буквы,мы ее будем брать) она будет храниться последним обьектом,так как массив отфильтрован и мы будем просто по нему идти
        }
        
        [section.itemsArray addObject:string]; // это имя добавим в массив айтемов для этой секции
    }
    */
    /*
    self.sectionsArray = [self generateSectionsFromArray:self.namesArray withFilter:self.searchBar.text]; //на основании оригинального массива namesArray соз массив секций с учетом фильтра
    [self.tableView reloadData]; // перезагрузим таблицу
     */
    
    [self generateSectionsInBackgroundFromArray:self.namesArray withFiler:self.searchBar.text];
    
}

//создадим метод,который будет считать операции в фоновом потоке

- (void) generateSectionsInBackgroundFromArray:(NSArray*) array withFiler:(NSString*) filterString { // точно такой же метод как ниже,только в Background потоке
    
    __weak ViewController* weakSelf = self;
    
    NSOperationQueue* operationQueue = [[NSOperationQueue alloc] init];
    
    [operationQueue addOperationWithBlock:^{
        
          NSArray* sectionsArray = [weakSelf generateSectionsFromArray:array withFilter:filterString];
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
           
            // Main thread work (UI usually)
            
            weakSelf.sectionsArray = sectionsArray;
            
            [weakSelf.tableView reloadData];
        }];
    }];
    
}

- (NSArray*) generateSectionsFromArray:(NSArray*) array withFilter:(NSString*) filterString { //соз метод с фильтром (копируем верхние строчки и изменяем)

    NSMutableArray* sectionsArray = [NSMutableArray array];
    
    NSString* currentLetter = nil;

    for (NSString* string in array) { //если в нашей cтроке будет содержатся фильтр,то мы его показываем,если не содерж.,то не показываем
        
        if ([filterString length] > 0 && [string rangeOfString:filterString].location == NSNotFound) { //ищем диапазон для строки filterString внутри нашей строки string ,если не находим
            continue; // continue - выйдет из текущего цикла и пойдет на следующий.
        }
        
        NSString* firstLetter = [string substringToIndex:1]; //берем у этой строки первую букву
        
        AGSection* section = nil;
        
        if (![currentLetter isEqualToString:firstLetter]) { //если currentLetter не равна ,тогда соз новую секцию (это для первого слова)
            
            section = [[AGSection alloc]init]; // инициализируем
            
            section.sectionName = firstLetter; //имя секции
            
            section.itemsArray = [NSMutableArray array];
            
            currentLetter = firstLetter; //чтобы узнали какая первая буква,чтобы в след. раз не соз ее
            
            [sectionsArray addObject:section]; //добавляем в массив эту section
            
        }else { // а для 2-го слова (если уже есть такая буква)
            
            section = [sectionsArray lastObject]; // секцию берем уже из массива (мы не будем соз еще раз секцию для той же самой буквы,мы ее будем брать) она будет храниться последним обьектом,так как массив отфильтрован и мы будем просто по нему идти
        }
        
        [section.itemsArray addObject:string]; // это имя добавим в массив айтемов для этой секции
    }
    
    return sectionsArray;
}

#pragma mark - UITableViewDataSource

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView { // метод,который паказывает indexBar (справа где скролинг выводит секции A.B.C.D...)
    
    NSMutableArray* array = [NSMutableArray array];//соз новый массив
    
    for (AGSection* section in self.sectionsArray) { // пройдемся по нашим секциям
        
        [array addObject:section.sectionName]; //в наш массив добавим имя каждой секции
    }
    
    return array;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { // кол-во секций в таблице

    return [self.sectionsArray count]; // кол-во элементов
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {

    return [[self.sectionsArray objectAtIndex:section] sectionName]; // берем массив секций , берем обьект под индексом секции и имя
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGSection* sec = [self.sectionsArray objectAtIndex:section];
    
    return [sec.itemsArray count];

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"Cell";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    AGSection* section = [self.sectionsArray objectAtIndex:indexPath.section];
    
    NSString* name = [section.itemsArray objectAtIndex:indexPath.row];
    
    //cell.textLabel.text = [self.namesArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = name;
    return cell;
}


#pragma mark - UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar { //когда начинаем вводить в SearchBаr везжает кнопка "Cancel"
    
    [searchBar setShowsCancelButton:YES animated:YES]; //анимировано показывает кнопку "Cancel"
    
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar __TVOS_PROHIBITED { // когда нажимаем кнопку "Cancel"

    [searchBar resignFirstResponder]; //убираем клава
    
    [searchBar setShowsCancelButton:NO animated:YES];

}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText { // метод вызывается,когда текст в "searchBar" поменялся

    NSLog(@"searchText %@", searchText);
    /*
    self.sectionsArray = [self generateSectionsFromArray:self.namesArray withFilter:searchText]; //на основании оригинального массива namesArray соз массив секций с учетом фильтра
    [self.tableView reloadData]; // перезагрузим таблицу
    */
    
    [self generateSectionsInBackgroundFromArray:self.namesArray withFiler:self.searchBar.text];
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
