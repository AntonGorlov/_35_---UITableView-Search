//
//  NSString+AGRandom.h
//  UITableView Search (Lesson 35)
//
//  Created by Anton Gorlov on 26.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AGRandom)

+ (NSString *)randomAlphanumericString;  //генератор строки без длины
+ (NSString *)randomAlphanumericStringWithLength:(NSInteger)length;// генератор строки с длиной


@end
