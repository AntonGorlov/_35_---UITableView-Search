//
//  AppDelegate.h
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 28.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

