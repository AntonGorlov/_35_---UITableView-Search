//
//  AGSection.m
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 05.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGSection.h"

@implementation AGSection

@end
