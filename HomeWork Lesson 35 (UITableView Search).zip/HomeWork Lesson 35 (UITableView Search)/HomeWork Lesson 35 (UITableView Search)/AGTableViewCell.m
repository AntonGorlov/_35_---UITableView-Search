//
//  AGTableViewCell.m
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 09.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGTableViewCell.h"

@implementation AGTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}



@end
