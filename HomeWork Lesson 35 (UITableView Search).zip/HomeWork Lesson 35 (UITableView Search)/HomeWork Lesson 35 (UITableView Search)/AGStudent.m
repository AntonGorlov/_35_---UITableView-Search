//
//  AGStudent.m
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 29.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

    static NSString *firstName [] = { @"Агнесса", @"Агния",   @"Ада",     @"Аза",     @"Алевтина",  @"Александра", @"Алина",      @"Алиса",     @"Алла",
                                      @"Беата",   @"Белла",   @"Берта",   @"Бета",    @"Богдана",   @"Борислава",  @"Бронислава", @"Валентина", @"Валерия",
                                      @"Глафира", @"Глория",  @"Дайна",   @"Данута",  @"Дарья",     @"Джульета",   @"Диана",      @"Дина",      @"Доля",
                                      @"Евгения", @"Евдокия", @"Клавдия", @"Клара",   @"Кристина",  @"Ксения",     @"Лада",       @"Лайма",     @"Лариса",
                                      @"Нина",    @"Нонна",   @"Нора",    @"Оксана",  @"Олеся",     @"Ольга",      @"Полина",     @"Доминика",  @"Ева",
                                      @"Альбина", @"Леся",    @"Лиана",

    };


    static NSString *lastName [] = { @"Иванова",   @"Смирнова",  @"Кузнецова",  @"Попова",    @"Соколова", @"Лебедева", @"Козлова",   @"Новикова",  @"Морозова",
                                     @"Петрова",   @"Волкова",   @"Соловаьева", @"Васильева", @"Зайцева",  @"Павлова",  @"Семенова",  @"Голубева",  @"Виноградова",
                                     @"Богданова", @"Воробьева", @"Федорова",   @"Михайлова", @"Беляева",  @"Тарасова", @"Белова",    @"Комарова",  @"Орлова",
                                     @"Киселева",  @"Макарова",  @"Андреева",   @"Ковалёва",  @"Ильина",   @"Гусева",   @"Ершова",    @"Никитина",  @"Соболева",
                                     @"Рябова",    @"Полякова",  @"Цветкова",   @"Данилова",  @"Жукова",   @"Фролова",  @"Журавлева", @"Николаева", @"Максимова",
                                     @"Сидорова",  @"Осипова",   @"Белоусова"
    
    };

static const NSInteger studentCount = 48;

+ (AGStudent *) createNewStudent {
    
    AGStudent *student = [[AGStudent alloc]init];
    student.firstName = firstName [arc4random() % studentCount];
    [student setLastName:lastName [arc4random() % studentCount]];
    
    NSDate *dateCurrent = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd.MM.yyyy"];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear fromDate:dateCurrent];
    
    NSInteger yearCurrent = [components year];
    NSInteger birthdateYear = yearCurrent - (arc4random() % 25 +18);
    NSInteger birthdateDay = arc4random()% 32;
    NSInteger birthdateMonth = arc4random() % 13;
    
    [components setDay:birthdateDay];
    [components setMonth:birthdateMonth];
    [components setYear:birthdateYear];
    
    student.birthdate = [calendar dateFromComponents:components];
    
    return student;

}



@end
