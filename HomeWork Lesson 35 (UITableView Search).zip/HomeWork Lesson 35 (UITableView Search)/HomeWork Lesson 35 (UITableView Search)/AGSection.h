//
//  AGSection.h
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 05.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGSection : NSObject

@property (strong, nonatomic) NSString *sectionName;
@property (strong, nonatomic) NSMutableArray *itemsArray;

@end
