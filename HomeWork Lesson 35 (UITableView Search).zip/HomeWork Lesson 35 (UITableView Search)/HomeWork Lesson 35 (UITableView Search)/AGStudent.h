//
//  AGStudent.h
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 29.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGStudent : NSObject

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSDate *birthdate;

+ (AGStudent*) createNewStudent;

@end
