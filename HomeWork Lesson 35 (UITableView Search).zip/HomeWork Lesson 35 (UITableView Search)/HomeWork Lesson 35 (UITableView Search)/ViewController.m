//
//  ViewController.m
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 28.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGStudent.h"
#import "AGSection.h"
#import "AGTableViewCell.h"

typedef enum {
    AGSortArrayDate,
    AGSortArrayFirstName,
    AGSortArrayLastName
}AGSortArray;
@interface ViewController ()

@property (strong, nonatomic) NSArray *studentArray ;
@property (strong, nonatomic) AGStudent *student;
@property (strong, nonatomic) NSArray *sectionsArray;

@property(assign, nonatomic)NSInteger controlState;

@end

@implementation ViewController

/*
 В этом уроке мы рассмотрели как один массив данных можно преобразовать в другой, более упорядоченный, да еще и с фильтрами. Нужно сделать пару практических упражнений.
 
 Ученик.
 
 1. Создайте класс студента. У него должны быть свойства: имя, фамилия и год рождения.
 2. Генерируйте случайное количество студентов и отобразите их в вашей таблице. (слева имя и фамилия, а справа дата рождения)
 
 Студент.
 
 3. Сгрупируйте студентов по секциям месяцев рождения, то есть все кто родился в январе в одной секции, а если в феврале никто не родился, то и секции такой нет.
 4. Внутри секции студенты должны быть отсортированы по имени по алфавиту, а если имена одинаковы, то и по фамилии (подсказка, лучше отсортировать массив вначале по 3 всем параметрам: дата, имя и фамилия)
 5. Добавьте индекс бар для быстрого перехода по секциям
 
 Мастер.
 
 6. Добавьте серчбар как в видео, чтобы кнопочка кенсел анимировано добавлялась/уезжала и тд
 7. Фильтруйте студентов каждый раз, когда вводится новая буква, причем совпадения ищите как в имени так и в фамилии
 
 Супермен
 
 8. Добавьте к серчбару сегментед контрол с тайтлами: Год рождения, Имя, фамилия (по умолчанию включен год рождения)
 9. Когда пользователь переключает сегментед контрол, то секции меняются на соответствующие. Например если выбран контрол с именем, то студенты должны быть отсортированы по имя-фамилия-дата, и должны быть собраны в секции, соответствующие первой букве имени.
 10. То же самое и для фамилий, фильтр = фамилия-дата-имя
 11. если выбрана дата, то все должно отсортироваться как в начале.
 
 желаю успехов :)
*/

- (void)viewDidLoad {
    [super viewDidLoad];
    
    int numberOfStudents =  20000 ;
    NSMutableArray* tempArray = [NSMutableArray array];
    
    for (int i = 0 ; i < numberOfStudents; i++) {
        
        AGStudent* student = [AGStudent createNewStudent];
        [tempArray addObject:student];
        
    }

    self.controlState = AGSortArrayDate;//sort by date is default
    self.studentArray = [self sortArray:tempArray forType:AGSortArrayDate];
    
   [self generateSectionsInBackgroundFromArray:self.studentArray withFilter:self.searchBar.text];
 
}


-(NSArray*)sortArray:(NSArray*)array forType:(AGSortArray) type{
    
    NSArray* sorted;
    NSSortDescriptor* firstName = [[NSSortDescriptor alloc]initWithKey:@"firstName" ascending:YES];
    NSSortDescriptor* lastName = [[NSSortDescriptor alloc]initWithKey:@"lastName" ascending:YES];
    
    
    switch (type) {
            
        case AGSortArrayDate:
        {
            NSMutableArray* tempArray = [NSMutableArray arrayWithArray:array];
            
            [tempArray sortUsingDescriptors:[NSArray arrayWithObjects:firstName,lastName, nil]];
            sorted = [self sortArray:tempArray];
            
            return sorted;
        }
            break;
            
            
        case AGSortArrayFirstName:
        {
            sorted = [self sortArray:array];
            NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sorted];
            [tempArray sortUsingDescriptors:[NSArray arrayWithObjects:firstName,lastName,nil]];
            
            return tempArray;
            
        }
            break;
            
            
        case AGSortArrayLastName:
        {
            sorted = [self sortArray:array];
            NSMutableArray* tempArray = [NSMutableArray arrayWithArray:sorted];
            [tempArray sortUsingDescriptors:[NSArray arrayWithObjects:lastName,firstName,nil]];
            
            return tempArray;
            
        }
            break;
            
        default:
            break;
    }
    
    return sorted;
}


-(NSArray*)sortArray:(NSArray*)array{
    
    NSDateFormatter* dt = [[NSDateFormatter alloc]init];
    [dt setDateFormat:@"MM"];
    
    NSArray* sorted = [array sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        
        NSString* string1 = [dt stringFromDate:[obj1 birthdate]];
        NSString* string2 = [dt stringFromDate:[obj2 birthdate]];
        
        return [string1 compare:string2];
    }];
    
    return sorted;
    
}


-(NSArray*)generationSectionFromArray:(NSArray*)array withFilter:(NSString*)filterString{
    
    NSMutableArray* sectionArray = [NSMutableArray array];
    NSString* currentLetter = nil;
    
    for (AGStudent* student  in array) {
        
        if ([filterString length] > 0 && [student.firstName rangeOfString:filterString].location == NSNotFound  && [student.lastName rangeOfString:filterString].location == NSNotFound) {
            continue;
        }
        
        NSString* firstLetter;
        
        if (self.controlState == AGSortArrayDate) {
            
            NSDateFormatter* dt = [[NSDateFormatter alloc]init];
            [dt setDateFormat:@"MMM"];
            
            firstLetter = [dt stringFromDate:student.birthdate];
        }else if(self.controlState == AGSortArrayFirstName){
            
            firstLetter = [student.firstName substringToIndex:1];
            
        }else if(self.controlState == AGSortArrayLastName){
            
            firstLetter = [student.lastName substringToIndex:1];
            
        }
        
        AGSection* section = nil;
        
        if (![currentLetter isEqualToString:firstLetter]) {
            
            section = [[AGSection alloc]init];
            section.sectionName = firstLetter;
            section.itemsArray = [NSMutableArray array];
            currentLetter = firstLetter;
            
            [sectionArray addObject:section];
            
        }else{
            section = [sectionArray lastObject];
        }
        
        [section.itemsArray addObject:student];
    }
    
    return sectionArray;
}

- (void) generateSectionsInBackgroundFromArray:(NSArray*) array withFilter:(NSString*) filterString {

    UIActivityIndicatorView* activityView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.color = [UIColor blueColor];
    activityView.center = self.view.center;
    
    [self.view addSubview:activityView];
    
    __weak ViewController* weakSelf = self;
    
    NSOperationQueue *operationQueue = [[NSOperationQueue alloc]init];
    [operationQueue addOperationWithBlock:^{
        
        [activityView startAnimating];
        NSArray* sectionArray = [weakSelf generationSectionFromArray:array withFilter:filterString];
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            
            weakSelf.sectionsArray = sectionArray;
            
            [weakSelf.tableView reloadData];
            [activityView stopAnimating];
        }];
    }];

}
#pragma mark - UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {


    return 50.f;
}

- (nullable NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView __TVOS_PROHIBITED {

    NSMutableArray* array = [[NSMutableArray alloc]init];

    for (AGSection* section in self.sectionsArray) {
        [array addObject:section.sectionName];
    }
    
    return array;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return [self.sectionsArray count];
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    AGSection* sectionStudent = [self.sectionsArray objectAtIndex:section];
    
    return sectionStudent.sectionName;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    AGSection* sectionStudent = [self.sectionsArray objectAtIndex:section];
    
    return [sectionStudent.itemsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    AGTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    AGSection* sectionStudent = [self.sectionsArray objectAtIndex:indexPath.section];
    AGStudent* student = [sectionStudent.itemsArray objectAtIndex:indexPath.row];
    
    cell.name.text = [NSString stringWithFormat:@"%@ %@", student.firstName, student.lastName];
    
    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"dd MMM yyyy"];
    
    NSString *dateString = [formatter stringFromDate:student.birthdate];
    
    cell.birthdayStudent.text = dateString;
    
    return cell;
    
}

#pragma mark -UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {

    [searchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar __TVOS_PROHIBITED {

    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
    
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {

    if ([searchBar isFirstResponder]) {
        [searchBar becomeFirstResponder];
        
    }
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {

    NSLog(@"Text did change %@", searchBar);
    
    [self generateSectionsInBackgroundFromArray:self.studentArray withFilter:self.searchBar.text];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionSort:(UISegmentedControl *)sender {
   
    self.controlState = sender.selectedSegmentIndex;
    self.studentArray = [self sortArray:self.studentArray forType:(AGSortArray)sender.selectedSegmentIndex];
    self.sectionsArray = [self generationSectionFromArray:self.studentArray withFilter:self.searchBar.text];
    [self.tableView reloadData];
    
}
@end
