//
//  ViewController.h
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 28.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController  <UITableViewDataSource,UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

- (IBAction)actionSort:(UISegmentedControl *)sender;

@end

