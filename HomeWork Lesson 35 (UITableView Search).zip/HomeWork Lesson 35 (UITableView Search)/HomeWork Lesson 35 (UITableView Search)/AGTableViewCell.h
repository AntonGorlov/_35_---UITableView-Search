//
//  AGTableViewCell.h
//  HomeWork Lesson 35 (UITableView Search)
//
//  Created by Anton Gorlov on 09.05.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *birthdayStudent;

@end
